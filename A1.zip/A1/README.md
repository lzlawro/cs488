# CS488 Winter 2023 Assignment 1

## Compilation
No changes were made to the default premake4/make combination.

No lab machine was used to test the code.

The code was tested on Thinkpad with Windows 10 running the VM.

## Manual
Objective 6 was not completed. The color editor cannot change the colors.

Objective 3 was not fully completed. Arrow keys can be used to move the avatar and it is blocked by walls, but the avatar is not spherical.
