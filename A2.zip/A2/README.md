# CS488 Winter 2023 Assignment 1

## Compilation
No changes were made to the default premake4/make combination.

No lab machine was used to test the code.

The code was tested on Thinkpad T14 Gen 2 with Windows 10 running the VM.

## Manual
The x, y, and z local axis of the model are colored in red, green and blue respectively.

The x, y, and z axis of the world are colored in cyan, magenta and yellow respectively.
