// Termm--Fall 2020

#pragma once

#include <string>

bool run_lua( const std::string& filename );
