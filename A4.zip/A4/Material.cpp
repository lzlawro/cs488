// Termm--Fall 2020

#include "Material.hpp"

Material::Material():
m_materialType(MaterialType::Material)
{}

Material::~Material()
{}
