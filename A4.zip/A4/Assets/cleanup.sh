rm *.png
cd ../
make clean
