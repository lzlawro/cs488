cd ../
make
cd Assets/
time ../A4 macho-cows.lua
time ../A4 simple-cows.lua
time ../A4 hier.lua
time ../A4 nonhier2.lua
time ../A4 nonhier.lua
time ../A4 sample.lua
mv *.png Images/